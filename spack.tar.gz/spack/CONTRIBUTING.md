# Contributing to Spack

Before contributing to Spack you should read the
[Contribution Guide](https://spack.readthedocs.io/en/latest/contribution_guide.html),
which is maintained as part of Spack's documentation.
